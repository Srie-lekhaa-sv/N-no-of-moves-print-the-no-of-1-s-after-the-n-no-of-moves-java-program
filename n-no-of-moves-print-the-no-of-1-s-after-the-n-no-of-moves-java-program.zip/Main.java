import java.util.*;
public class Main {
    public static void main(String args[]) {
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(), a[] = new int[n];
        for (int i = 1; i <= n; i++) {
            for (int j = i; j <= n; j++) {
                if (j % i == 0) {
                    if (a[j - 1] == 0) {
                        a[j - 1] = 1;
                    } else {
                        a[j - 1] = 0;
                    }
                }
            }
        }
        int c = 0;
        for (int i = 0; i < n; i++) {
            if (a[i] == 1) {
                c++;
            }
        }
        System.out.println(c);
    }
}